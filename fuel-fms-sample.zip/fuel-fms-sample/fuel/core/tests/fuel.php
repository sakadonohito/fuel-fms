<?php
/**
 * Part of the Fuel framework.
 *
 * @package    Fuel
 * @version    1.6
 * @author     Fuel Development Team
 * @license    MIT License
 * @copyright  2010 - 2013 Fuel Development Team
 * @link       http://fuelphp.com
 */

namespace Fuel\Core;

/**
 * Fuel class tests
 *
 * @group Core
 * @group Fuel
 */
class Test_Fuel extends TestCase
{
 	public function test_foo() {}
}
