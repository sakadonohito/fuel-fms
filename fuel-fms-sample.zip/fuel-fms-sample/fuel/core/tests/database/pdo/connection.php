<?php
/**
 * Part of the Fuel framework.
 *
 * @package    Fuel
 * @version    1.6
 * @author     Fuel Development Team
 * @license    MIT License
 * @copyright  2010 - 2013 Fuel Development Team
 * @link       http://fuelphp.com
 */

namespace Fuel\Core;

/**
 * Database_Pdo_Connection class tests
 *
 * @group Core
 * @group Database
 */
class Test_Database_Pdo_Connection extends TestCase
{
 	public function test_foo() {}
}
