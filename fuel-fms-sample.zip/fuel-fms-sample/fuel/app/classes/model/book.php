<?php
class Model_Book extends Model_Fms_Fmserver {
    protected static $_table_name = 'book';
}
?>
