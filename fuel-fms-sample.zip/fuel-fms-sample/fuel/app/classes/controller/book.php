<?php
use Fuel\Core;
class Controller_Book extends Controller {
    //Top page
    public function action_index() {

        $view = View::forge('template');
        $data['title'] = '図書検索';
        $view->nav = array('class=active','','','');
        $form = Fieldset::forge('search_form',array(
                                    'form_attributes'=>array(
                                    'class'=>'form-search')));
        $form->add('keyword','',array('type'=>'text','size'=>'200','value'=>'','class'=>'search-query','placeholder'=>'検索したいキーワードを入力'));
        $form->add('submit','',array('type'=>'submit','value'=>'　検  索　','class'=>'btn-primary'));
        $view->contents = View::forge('book/index',$data)->set('form',$form->build('book/search'),false);
//        $view->contents = View::forge('book/index');
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    //input search
    public function action_input() {
        //検索画面に移動する
        $view = View::forge('template');
        //$view->title = '検索条件入力';
        $view->nav = array('','','class=active','');
        $form = Fieldset::forge('search_form');
        $form->add('title','タイトル',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('title_kana','タイトル：よみ',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('series','シリーズ名',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('kan','巻',array('type'=>'text','size'=>'6','value'=>''));
        $form->add('title_sub','サブタイトル',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('author','著者',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('author_kana','著者：よみ',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('publisher','出版社',array('type'=>'text','size'=>'100','value'=>''));
        $form->add('publish_date','出版年',array('type'=>'text','size'=>'10','value'=>''));
        $form->add('submit','',array('type'=>'submit','value'=>'　検　索　','class'=>'btn-primary'));
        $view->contents = View::forge('book/input')->set('form',$form->build('book/search'),false);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    //検索する
    public function action_search() {
        //値が入っているかチェック
        $cond = array();
        if(null != Input::post('keyword')){
            $cond['book_info_for_search'] = Input::post('keyword');
        }else{

            if(null != Input::post('title')){
                $cond['title'] = Input::post('title');
            }
            if(null != Input::post('title_kana')){
                $cond['title_kana'] = Input::post('title_kana');
            }
            if(null != Input::post('author')){
                $cond['author'] = Input::post('author');
            }
            if(null != Input::post('author_kana')){
                $cond['author_kana'] = Input::post('author_kana');
            }
            if(null != Input::post('title_sub')){
                $cond['title_sub'] = Input::post('title_sub');
            }
            if(null != Input::post('kan')){
                $cond['kan'] = Input::post('kan');
            }
            if(null != Input::post('series')){
                $cond['series'] = Input::post('series');
            }
            if(null != Input::post('publisher')){
                $cond['publisher'] = Input::post('publisher');
            }
            if(null != Input::post('publish_date')){
                $cond['publish_date'] = Input::post('publish_date');
            }

        }

        if(count(array_values($cond)) > 0){
            $is_input = true;
        }else{
            $is_input = false;
        }

        if($is_input){
            //検索
            //$fms = Model_Book::forge();
            //Model_Book::setFmsInfo(array('lay'=>'Book_List'));
            //$fms->createFmServer();
            //Model_Book::$fms->AddSortParam('date_ukeire','ascend',1);
            //Model_Book::$fms->AddSortParam('title_full_display','ascend',2);
            Model_Book::getFmServer('Book_List');
            Model_Book::addSortParam(
                array(
                    array('field'=>'date_ukeire','ad'=>'ascend','order'=>1),
                    array('field'=>'title_full_display','ad'=>'ascend','order'=>2)
));
            Session::set('cond',$cond);
            $result = Model_Book::find($cond);

	        $data['books'] = $result;
	
	        $view = View::forge('template');
	        $view->title = '図書一覧';
            $view->nav = array('','','','');

	        $view->contents = View::forge('book/list',$data);
	        $view->footer = View::forge('layout/footer');
	        return Response::forge($view);
        }else{
            $data['error'] = 'キーワードを入力して検索してください。';
	        $view = View::forge('template');
	        $view->title = '検索条件入力';
            $view->nav = array('','','class=active','');
	        $view->contents = View::forge('book/input',$data);
	        $view->footer = View::forge('layout/footer');
            return Response::forge($view);
        }
    }

    //検索する
    public function action_search_newbook() {
        $tdy = new DateTime('now');
        $today = $tdy->format('m/d/Y');
        $pMon = $tdy->sub(new DateInterval("P1M"));
        $preMonth = $pMon->format('m/d/Y');
        //$preMonth->sub(new DateInterval("P1M"));
        // mm/dd/yyyy
        $cond['date_ukeire'] = "${preMonth}...${today}";

        //検索
        //$fms = Model_Book::forge();
        //Model_Book::setFmsInfo(array('lay'=>'Book_List'));
        //$fms->createFmServer();
        //Model_Book::$fms->AddSortParam('date_ukeire','ascend',1);
        //Model_Book::$fms->AddSortParam('title_full_display','ascend',2);
        Model_Book::getFmServer('Book_List');
        Model_Book::addSortParam(
            array(
                array('field'=>'date_ukeire','ad'=>'ascend','order'=>1),
                array('field'=>'title_full_display','ad'=>'ascend','order'=>2)
));
        Session::set('cond',$cond);
        $result = Model_Book::find($cond);
        $data['books'] = $result;

        $view = View::forge('template');
        $view->title = '図書一覧';
        $view->nav = array('','','','');

        $view->contents = View::forge('book/list',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    //検索する
    public function action_list($page=0) {

        $cond = Session::get('cond');

        //検索
        //$fms = Model_Book::forge();
        //Model_Book::setFmsInfo(array('lay'=>'Book_List'));
        //$fms->createFmServer();
        //Model_Book::$fms->FMSkipRecords(($page-1)*50);
        //Model_Book::$fms->AddSortParam('date_ukeire','ascend',1);
        //Model_Book::$fms->AddSortParam('title_full_display','ascend',2);
        Model_Book::getFmServer('Book_List');
        Model_Book::addSortParam(
            array(
                array('field'=>'date_ukeire','ad'=>'ascend','order'=>1),
                array('field'=>'title_full_display','ad'=>'ascend','order'=>2)
));
        Model_Book::addSkip(($page-1)*50);

        Session::set('cond',$cond);
        $result = Model_Book::find($cond);
        $data['books'] = $result;

        $view = View::forge('template');
        $view->title = '図書一覧';
        $view->nav = array('','','','');

        $view->contents = View::forge('book/list',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    public function action_detail($id=null) {
        //$fms = Model_Book::forge();
        //Model_Book::setFmsInfo(array('lay'=>'Book_Detail'));
        //$fms->createFmServer();
        //$rs = $fms->find_by_pk($id);
        Model_Book::getFmServer('Book_Detail');
        //Session::set('cond',$cond);
        $rs = Model_Book::find_by_pk($id);
        $data['book'] = array_shift($rs);
        $view = View::forge('template');
        $view->title = '図書詳細';
        $view->nav = array('','','','');
        $view->contents = View::forge('book/detail',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    public function action_delete($id=null) {
        $fms = Model_Book::forge();
        //Model_Book::setFmsInfo(array('lay'=>'Book_Detail'));
        //$fms->createFmServer();
        Model_Book::getFmServer('Book_Detail');
        //$fms->fm = $fms->find_by_pk($id);
        $fms->fm['-recid'] = $id;
        $data['result'] = $fms->delete();
        $view = View::forge('template');
        $view->title = '図書詳細';
        $view->nav = array('','','','');
        $view->contents = View::forge('book/delete',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    public function action_edit($id=null){
        if(null == $id){
            $data['book'] = null;
        }else{
	        $fms = Model_Book::forge();
            //Model_Book::setFmsInfo(array('lay'=>'Book_Detail'));
	        //$fms->createFmServer();
            Model_Book::getFmServer('Book_Detail');
            $result = $fms->find_by_pk($id);
	        $data['book'] = array_shift($result);
        }

        $view = View::forge('template');
        $view->title = '図書入力';
        $view->nav = array('','','','class=active');

        $form = Fieldset::forge('edit_form');

        if(null != $data['book']){
            $form->add('-recid','-recid',array('type'=>'hidden','value'=>$data['book']['record_id']));
        }
        $form->add('isbn','ISBN',array('type'=>'text','size'=>'13','value'=>$data['book']['isbn']));
        $form->add('title','TITLE',array('type'=>'text','size'=>'40','value'=>$data['book']['title']));
        $form->add('title_kana','TITLE_KANA',array('type'=>'text','size'=>'40','value'=>$data['book']['title_kana']));
        $form->add('kan','巻',array('type'=>'text','size'=>'40','value'=>$data['book']['kan']));
        $form->add('title_sub','サブタイトル',array('type'=>'text','size'=>'40','value'=>$data['book']['title_sub']));
        $form->add('han','版',array('type'=>'text','size'=>'40','value'=>$data['book']['han']));
        $form->add('series','シリーズ名',array('type'=>'text','size'=>'40','value'=>$data['book']['series']));
        $form->add('author','著者',array('type'=>'text','size'=>'40','value'=>$data['book']['author']));
        $form->add('author_kana','著者よみがな',array('type'=>'text','size'=>'40','value'=>$data['book']['author_kana']));
        $form->add('publisher','出版社',array('type'=>'text','size'=>'40','value'=>$data['book']['publisher']));
        $form->add('date_ukeire','受入日',array('type'=>'text','size'=>'40','value'=>$data['book']['date_ukeire']));
        $form->add('submit','',array('type'=>'submit','class'=>'btn-primary','value'=>'　確　定　'));

        $view->contents = View::forge('book/edit',$data)->set('form',$form->build('book/save'),false);

        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    public function action_save($id=null){
        $book = Model_Book::forge();
        //Model_Book::setFmsInfo(array('lay'=>'Book_Detail'));
        //$book->createFmServer();
        Model_Book::getFmServer('Book_Detail');
        $array = array(
                       'isbn'=>Input::post('isbn'),
                       'title'=>Input::post('title'),
                       'title_kana'=>Input::post('title_kana'),
                       'title_sub'=>Input::post('title_sub'),
                       'kan'=>Input::post('kan'),
                       'han'=>Input::post('han'),
                       'series'=>Input::post('series'),
                       'author'=>Input::post('author'),
                       'author_kana'=>Input::post('author_kana'),
                       'publisher'=>Input::post('publisher'),
                       'date_ukeire'=>Input::post('date_ukeire'),
                       );
        if(null != Input::post('-recid')){
            $array['-recid'] = Input::post('-recid');
        }
        $book->set($array);

        $result = $book->save();
        $data['book'] = $result;
        $view = View::forge('template');
        $view->title = '結果表示';
        $view->nav = array('','','','');
        $view->contents = View::forge('book/display_book',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);        
    }

    //Test fms to MySQL
    public function action_ess_mysql($page=1) {

        Model_Book::getFmServer('mysql_redmine_issues');
        Model_Book::addSortParam(
            array(
                array('field'=>'start_date','ad'=>'ascend','order'=>1)
));
        Model_Book::addSkip(($page-1)*50);

        $result = Model_Book::find_all();
        $data['books'] = $result;

        $view = View::forge('template');
        $view->title = 'Sample ESS';
        $view->nav = array('','','','');

        $view->contents = View::forge('book/ess',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }

    //Test fms to Oracle
    public function action_ess_oracle($page=1) {

        Model_Book::getFmServer('TEAMS');
        Model_Book::addSkip(($page-1)*50);

        $result = Model_Book::find_all();
        $data['books'] = $result;

        $view = View::forge('template');
        $view->title = 'Sample ESS Oracle';
        $view->nav = array('','','','');

        $view->contents = View::forge('book/oracle',$data);
        $view->footer = View::forge('layout/footer');
        return Response::forge($view);
    }
}
