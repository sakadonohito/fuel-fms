<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta charset="utf-8">
	<title>図書管理</title>

<?php echo Asset::css(array('bootstrap.css',
                            'bootstrap-responsive.css'
                      )); ?>
	<?php echo Asset::js(array(
		'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js',
		'bootstrap.js'
	)); ?>
</head>
<body>

  <div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
      <div class="container">
        <a class="brand">図書管理</a>
        <ul class="nav">
          <li <?php echo $nav[0]; ?>><?php echo Html::anchor('book','簡易検索'); ?></li>
          <li class="divider-vertical"></li>
		  <li <?php echo $nav[1]; ?>><?php echo Html::anchor('book/search_newbook','新着図書'); ?></li> 
          <li class="divider-vertical"></li>
		  <li <?php echo $nav[2]; ?>><?php echo Html::anchor('book/input','詳細検索'); ?></li>
          <li class="divider-vertical"></li>
		  <li <?php echo $nav[3]; ?>><?php echo Html::anchor('book/edit','新規作成'); ?></li>
		</ul>
      </div>
    </div>
  </div>
<div><br/><br/><br/></div>
  <div class="container">
    <div class="contents">
<?php echo $contents; ?>
    </div>
    <div class="footer">
<?php echo $footer; ?>
    </div>
  </div>
</body>
</html>
