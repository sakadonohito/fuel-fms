<h3>図書一覧</h3>
<table class="table table-borderd table-striped">
<th>詳細</th><th>行番号</th><th>図書情報</th><th>出版年</th><th>本棚</th><th>分類番号</th><th>貸出可否</th><th>貸出状態</th><th>受入日</th>
<?php 
if(isset($books) && !isset($books['error'])){
    $cnt = $books['foundCount'];
    $booksData = $books['data'];

    echo "<tbody>";

    foreach($booksData as $book){
        echo "<tr><td>";
        echo Html::anchor('book/detail/'.$book['record_id'],'▼');
        echo "</td>";

        echo "<td>${book['record_number']}</td>".
             "<td>${book['title_full_display']}</td>".
             "<td>${book['publish_date']}</td>".
             "<td>${book['Web_BookShelf::shelf_name']}".
             "<td>${book['invoice_number']}</td>";
        echo ($book['flag_lend'])?'<td><span class="label label-success">貸出可能</span></td>':'<td><span class="label label-important">貸出不可</span></td>';
        echo ($book['status'] != null && $book['status'] == 0)? '<td><span class="label label-warning">貸出中</span></td>':"<td></td>";
        if(null != $book['date_ukeire']){
            $d = new DateTime($book['date_ukeire']);
            echo "<td>".$d->format('Y-m-d')."</td>";
        }else{
            echo "<td></td>";
        }
        echo "</tr>";
    }
    echo "</tbody></table>";

    $rsCount = $books['foundCount'];
    if(strpos($books['URL'],'skip=')){
        preg_match('/skip=([0-9]*)/',$books['URL'],$cnt);
        $current = $cnt[1]+1;
        $currentPage = ceil($current/50);
    }else{
        $current = 1;
        $currentPage = 1;
    }
    $pageCount = ceil($rsCount/50);

    echo "<div class='pagination'><ul>";
    if($pageCount > 1){
	    for($i = 1;$i<$pageCount+1;$i++){
            if($currentPage == $i){
                //現在のページ
                echo sprintf("<li class='active'><a href='#'>%s</a></li>",$i);
            }else{
                echo "<li>".Html::anchor('book/list/'.$i,$i)."</li>";
            }
	    }
    }
    echo "</ul></div>";
}elseif(isset($books['error'])){
    echo "<div>${books['error']}</div>";
}else{
    echo "<div>${error}</div>";
}
?>
