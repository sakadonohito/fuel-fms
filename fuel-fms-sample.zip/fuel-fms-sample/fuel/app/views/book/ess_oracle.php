<h3>Sample ESS</h3>
<table class="table table-borderd table-striped">
<th>No</th><th>name</th><th>league</th>
<?php 
if(isset($books) && !isset($books['error'])){
    $cnt = $books['foundCount'];
    $booksData = $books['data'];

    echo "<tbody>";

    foreach($booksData as $book){
        echo "<td>${book['record_number']}</td>".
             "<td>${book['NAME']}</td>".
             "<td>${book['LEAGUE']}</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";

    $rsCount = $books['foundCount'];
    if(strpos($books['URL'],'skip=')){
        preg_match('/skip=([0-9]*)/',$books['URL'],$cnt);
        $current = $cnt[1]+1;
        $currentPage = ceil($current/50);
    }else{
        $current = 1;
        $currentPage = 1;
    }
    $pageCount = ceil($rsCount/50);

    echo "<div class='pagination'><ul>";
    if($pageCount > 1){
	    for($i = 1;$i<$pageCount+1;$i++){
            if($currentPage == $i){
                //現在のページ
                echo sprintf("<li class='active'><a href='#'>%s</a></li>",$i);
            }else{
                echo "<li>".Html::anchor('book/oracle/'.$i,$i)."</li>";
            }
	    }
    }
    echo "</ul></div>";
}elseif(isset($books['error'])){
    echo "<div>${books['error']}</div>";
}else{
    echo "<div>${error}</div>";
}
?>
