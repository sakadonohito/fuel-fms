<div><pre>
<?php print_r($books);?>
</pre></div>
<?php echo Html::anchor('book/index','Top'); ?>