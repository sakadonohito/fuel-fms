<h3>Sample ESS</h3>
<table class="table table-borderd table-striped">
<th>No</th><th>subject</th><th>description</th><th>due_date</th><th>start_date</th><th>done_ratio</th>
<?php 
if(isset($books) && !isset($books['error'])){
    $cnt = $books['foundCount'];
    $booksData = $books['data'];

    echo "<tbody>";

    foreach($booksData as $book){
        echo "<td>${book['record_number']}</td>".
             "<td>${book['subject']}</td>".
             "<td>${book['description']}</td>";
        if(null != $book['due_date']){
            $d = new DateTime($book['due_date']);
            echo "<td>".$d->format('Y-m-d')."</td>";
        }else{
            echo "<td></td>";
        }
        if(null != $book['start_date']){
            $d = new DateTime($book['start_date']);
            echo "<td>".$d->format('Y-m-d')."</td>";
        }else{
            echo "<td></td>";
        }
        echo "<td>${book['done_ratio']}</td>";

        echo "</tr>";
    }
    echo "</tbody></table>";

    $rsCount = $books['foundCount'];
    if(strpos($books['URL'],'skip=')){
        preg_match('/skip=([0-9]*)/',$books['URL'],$cnt);
        $current = $cnt[1]+1;
        $currentPage = ceil($current/50);
    }else{
        $current = 1;
        $currentPage = 1;
    }
    $pageCount = ceil($rsCount/50);

    echo "<div class='pagination'><ul>";
    if($pageCount > 1){
	    for($i = 1;$i<$pageCount+1;$i++){
            if($currentPage == $i){
                //現在のページ
                echo sprintf("<li class='active'><a href='#'>%s</a></li>",$i);
            }else{
                echo "<li>".Html::anchor('book/ess/'.$i,$i)."</li>";
            }
	    }
    }
    echo "</ul></div>";
}elseif(isset($books['error'])){
    echo "<div>${books['error']}</div>";
}else{
    echo "<div>${error}</div>";
}
?>
