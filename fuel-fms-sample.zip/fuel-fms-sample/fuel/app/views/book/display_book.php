<div>
<?php print_r($book);?>
</div>
