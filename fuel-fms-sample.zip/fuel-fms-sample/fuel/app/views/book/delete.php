<div>
<?php print_r($result); ?>
</div>
