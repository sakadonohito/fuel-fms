<div class="contents_header">
<p>編集入力</p>
</div>
<div class="main">
<?php echo $form; ?>
</div>
