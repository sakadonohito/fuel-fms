<h3>検索条件を入力してください。</h3>
<div>
<?php echo (isset($form))? $form : null; ?>
</div>
<?php 
if(isset($error)){
    echo "<div>エラー： ${error}</div>";
}
?>
