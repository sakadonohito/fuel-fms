<div class="hero-unit">
<?php echo "<h1>$title</h1>";?>
</div>
<div>
<h3>検索したい書籍のタイトルや著者名を入力して検索してください。</h3>
<?php echo $form; ?>
</div>
<?php 
if(isset($error)){
    echo "<div><pre>エラー： ${error}</pre></div>";
}

if(isset($debug)){
    echo "<div><pre>";
    print_r($debug);
    echo "</pre></div>";
}
?>






