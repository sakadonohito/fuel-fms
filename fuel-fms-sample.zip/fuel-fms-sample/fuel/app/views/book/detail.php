<div class="contents_header">
<h2>図書詳細</h2>
<dl class="dl-horizontal">
  <dt>図書ID</dt><dd><?php echo "　".$book['book_id'];?></dd>
  <dt>ISBN</dt><dd><?php echo "　".$book['isbn'];?></dd>
  <dt>ISSN</dt><dd><?php echo "　".$book['issn'];?></dd>
  <dt>分類情報</dt><dd><?php echo "　${book['Web_NDC01::ndc_name_01']}　${book['Web_NDC02::ndc_name_02']}　${book['Web_NDC03::ndc_name_03']} ( ${book['invoice_number']} )";?></dd>
  <dt>ジャンル</dt><dd><?php echo "　".$book['genre_name'];?></dd>
  <dt>本棚</dt><dd><?php echo "　".$book['Web_BookShelf::shelf_name'];?></dd>
  <dt>区分</dt><dd><?php echo "　".$book['kubun_data'];?></dd>

  <dt>タイトル</dt><dd><?php echo "　".$book['title'];?></dd>
  <dt>タイトル よみ</dt><dd><?php echo "　".$book['title_kana'];?></dd>
  <dt>版情報</dt><dd><?php echo "　".$book['han'];?></dd>
  <dt>巻情報</dt><dd><?php echo "　".$book['kan'];?></dd>
  <dt>シリーズ名</dt><dd><?php echo "　".$book['series'];?></dd>
  <dt>サブタイトル</dt><dd><?php echo "　".$book['title_sub'];?></dd>
  <dt>著者</dt><dd><?php echo "　".$book['author'];?></dd>
  <dt>著者 よみ</dt><dd><?php echo "　".$book['author_kana'];?></dd>
  <dt>出版社</dt><dd><?php echo "　".$book['publisher'];?></dd>
  <dt>出版年</dt><dd><?php echo "　".$book['publish_date'];?></dd>

  <dt>貸出可能期間</dt><dd><?php echo "　".$book['lending_period'].' 日';?></dd>
  <dt>貸出区分</dt><dd><?php echo ($book['flag_lend'])?'　<span class="label label-success">貸出可能</span>':'　<span class="label label-important">貸出不可</span>';?></dd>
  <dt>状態</dt><dd><?php echo ($book['status'] != null && $book['status'] == 0)? '　<span class="label label-warning">貸出中</span>':"　";?></dd>
</dl>

<div>
<?php echo Html::anchor('book/edit/'.$book['record_id'],'編集',array('class'=>'btn btn-primary')); ?> | 
<?php echo Html::anchor('book/delete/'.$book['record_id'],'削除',array('class'=>'btn btn-danger')); ?>
</div>
<div class="contents_footer">

</div>
