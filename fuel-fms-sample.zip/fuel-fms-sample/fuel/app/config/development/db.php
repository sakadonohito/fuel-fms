<?php
/**
 * The development database settings. These get merged with the global settings.
 */

return array(

	/*
	 * If you don't specify a DB configuration name when you create a connection
	 * the configuration to be used will be determined by the 'active' value
	 */
	'active' => 'fmserver',

	/**
	 * Base FileMaker Server config
	 */
	'fmserver' => array(
		'host'     => '127.0.0.1',
        'port'     => '80',
        'scheme'   => 'http',
        'database' => 'tm_web',
        'user'     => 'web',
        'pass'     => 'WebUser'
	),

	/**
	 * Base MySQLi config
	 */

	'default' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=localhost;dbname=fuel_prod',
			'username'   => 'fuel_app',
			'password'   => 'super_secret_password',
		),
	),

	'sample_mysql' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=localhost;dbname=fuel_dev',
			'username'   => 'root',
			'password'   => 'root',
		),
	),

	/**
	 * Base PDO config
	 */
	'sample_pdo' => array(
		'type'        => 'pdo',
		'connection'  => array(
			'persistent' => false,
			'compress'   => false,
		),
		'identifier'   => '`',
		'table_prefix' => '',
		'charset'      => 'utf8',
		'enable_cache' => true,
		'profiling'    => false,
	),

	/**
	 * Base Redis config
	 */
	'sample_redis' => array(
		'default' => array(
			'hostname'  => '127.0.0.1',
			'port'      => 6379,
			'timeout'	=> null,
		)
	),

);
