<?php
return array(
	'crypto_key' => 'Mqsj4Ygsg_c4iP8N4crcQBU4',
	'crypto_iv' => 'ISMycQ9JIgJccWIK1sZRQ1Zw',
	'crypto_hmac' => '6g8C2AVq4UKkkTwzMQJ_Ygls',
);
